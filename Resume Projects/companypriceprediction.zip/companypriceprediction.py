import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import seaborn as sns;
import sklearn;
from sklearn.model_selection import train_test_split;
from sklearn.linear_model import LinearRegression;
from sklearn.linear_model import LogisticRegression;
from sklearn.tree import DecisionTreeClassifier;
from sklearn.tree import DecisionTreeRegressor;
from sklearn.preprocessing import LabelEncoder;
from sklearn.preprocessing import MinMaxScaler;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import classification_report;
company_data=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\2022_Forbes_list.csv');
print(company_data);
print(company_data.shape);
print(len(company_data));

lab=LabelEncoder();
company_data['Headquarters']=lab.fit_transform(company_data['Headquarters']);
print(company_data['Headquarters'].unique());
print(company_data['Headquarters']);

company_data=company_data.drop('Changes Rank from last Year',axis=1);
print(company_data);

x_axis=company_data[['Rank in India','Forbes 2000 rank in World','Headquarters','Revenue(billions US$)','Profit(billions US$)','Assets(billions US$)','Value(billions US$)']];
print("The x axis is");print(x_axis);
y_axis=company_data['Name'];
print("The y axis is");print(y_axis);



X_train,X_test,y_train,y_test=train_test_split(x_axis,y_axis,test_size=0.33,random_state=0);
company_model=DecisionTreeClassifier(criterion="entropy",random_state=100,max_depth=13,min_samples_leaf=5);
company_model.fit(X_train,y_train);

y_prediction=company_model.predict(X_test);
print("The y prediction test is as follows");
y_prob_prediction=company_model.predict_proba(X_test);
print(y_prediction);

cm=confusion_matrix(y_prediction,y_test);
print(cm);
cr=classification_report(y_prediction,y_test);
print(cr);

print(company_model.predict([[2,12,5,226.6,123.4,123.5,65.1]]));
