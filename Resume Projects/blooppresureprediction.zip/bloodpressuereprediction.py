import numpy as np;
import pandas as pd;
import sklearn;
import matplotlib.pyplot as plt;
import seaborn as sns;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import classification_report;
from sklearn.preprocessing import LabelEncoder;
from sklearn.linear_model import LogisticRegression;
from sklearn.model_selection import train_test_split;
#here logistic regression is also called as the logistic classification and used to classification of the categorical objects
medical_insurance=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\Medicalpremium.csv');
print(medical_insurance);
print(medical_insurance.shape);
print(len(medical_insurance));

#dropping the price of the dataset
medical_insurance=medical_insurance.drop('PremiumPrice',axis=1);
print(medical_insurance);

#predicting the blood-pressure of the patient
#sns.heatmap(medical_insurance);
#plt.show();

x_axis=medical_insurance[['Age','Diabetes','AnyTransplants','AnyChronicDiseases','Height','Weight','KnownAllergies','HistoryOfCancerInFamily','NumberOfMajorSurgeries']];
print(x_axis);
y_axis=medical_insurance['BloodPressureProblems'];
print(y_axis);

#now creating the classification model
medical_model=LogisticRegression();
print(medical_model);
print(type(medical_insurance));

X_train,X_test,y_train,y_test=train_test_split(x_axis,y_axis,test_size=0.33,random_state=0);
medical_model.fit(X_train,y_train);
y_prediction=medical_model.predict(X_test);
print(y_prediction);

#finding the confusion matrix
print("printing the confusion matrix");
cm=confusion_matrix(y_prediction,y_test);
print(cm);
print(type(cm));


#finding the classification report
print("printing the classification report");
cr=classification_report(y_prediction,y_test);
print(cr);
print(type(cr));

#now predicting the blood pressure in patients
age=int(input("Enter the age of the person="));
diabetes=int(input("Does the person have diabeties="));
anytransplant=int(input("Does the person have any transplant="));
anychronic=int(input("Does the person have any chronic diseases="));
height=int(input("What is the height of the person="));
weight=int(input("What is the wieght of the person="));
knonallergies=int(input("Does the person have any allergiy ="));
cancer=int(input("Does the person have any cancer in the family="));
surjery=int(input("What is the total number of surgeris the person have="));

print(medical_model.predict([[age,diabetes,anytransplant,anychronic,height,weight,knonallergies,cancer,surjery]]));



