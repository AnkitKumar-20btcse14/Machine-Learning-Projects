import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
import seaborn as sns;
import collections;
import sklearn;
from sklearn.model_selection import train_test_split;
from sklearn.linear_model import LinearRegression;
from sklearn.preprocessing import LabelEncoder;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import classification_report;

car_data=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\CarPrice_Assignment.csv');
print(car_data);
print(car_data.shape);
print(len(car_data));


car_data=car_data.drop('car_ID',axis=1);
car_data=car_data.drop('symboling',axis=1);
car_data=car_data.drop('aspiration',axis=1);
car_data=car_data.drop('stroke',axis=1);
print(car_data);

lab=LabelEncoder();
car_data['CarName']=lab.fit_transform(car_data['CarName']);
car_data['fueltype']=lab.fit_transform(car_data['fueltype']);
#car_data['aspiration']=lab.fit_transform(car_data['aspiration']);
car_data['doornumber']=lab.fit_transform(car_data['doornumber']);
car_data['carbody']=lab.fit_transform(car_data['carbody']);
car_data['drivewheel']=lab.fit_transform(car_data['drivewheel']);
car_data['enginelocation']=lab.fit_transform(car_data['enginelocation']);
car_data['enginetype']=lab.fit_transform(car_data['enginetype']);
car_data['cylindernumber']=lab.fit_transform(car_data['cylindernumber']);
car_data['fuelsystem']=lab.fit_transform(car_data['fuelsystem']);
print(car_data);

x_axis=car_data[['CarName','fueltype','doornumber','carbody','drivewheel','enginelocation','wheelbase','carlength','carwidth','carheight','curbweight','enginetype','cylindernumber','enginesize','boreratio','compressionratio','horsepower','peakrpm','citympg','highwaympg']];
y_axis=car_data['price'];
print(y_axis);
print(y_axis.shape);

X_train,X_test,y_train,y_test=train_test_split(x_axis,y_axis,test_size=0.33,random_state=0);
car_model=LinearRegression();
car_model.fit(X_train,y_train);

carname=int(input("Enter the name of the car="));
fueltype=int(input("Enter the fuel type"));
doornumber=int(input("Enter the number of doors="));
carbody=int(input("Enter the body of the car="));
drivewheel=int(input("Enter the drive wheel of the car="));
enginelocation=int(input("Enter the engine location of the car="));
wheelbase=int(input("Enter the wheel base of the car="));
carlength=int(input("Enter the length of the car="));
carwidth=int(input("Enter the width of the car="));
carheight=int(input("Enter the height of the car="));
curbeweight=int(input("Enter the wegith of the curbe="));
enginetype=int(input("Enter the engine type of the car="));
cylindernumber=int(input("Enter the cylinder number of the car="));
enginesize=int(input("Enter the engine size of the car="));
boreratio=int(input("Enter the boreratio of the car="));
compressionpower=int(input("Enter the compression power of the car="));
horsepower=int(input("Enter the horsepower of the car="));
peakrpm=int(input("Enter the rpm of the peak of the car="));
citympg=int(input("Enter the mpg of the city="));
highwaympg=int(input("Enter the mpg of the highway="));

print(car_model.predict([[carname,fueltype,doornumber,carbody,drivewheel,enginelocation,wheelbase,carlength,carwidth,carheight,curbeweight,enginetype,cylindernumber,enginesize,boreratio,compressionpower,horsepower,peakrpm,citympg,highwaympg]]));
