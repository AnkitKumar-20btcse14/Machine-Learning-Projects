import numpy as np;
import pandas as pd;
import collections;
from collections import deque;
import matplotlib.pyplot as plt;
import seaborn as sns;
import sklearn;
from sklearn.model_selection import train_test_split;
from sklearn.model_selection import tests;
from sklearn.linear_model import LogisticRegression;
from sklearn.tree import DecisionTreeRegressor;  #it is used in case of classification
from sklearn.tree import DecisionTreeClassifier;
from sklearn.datasets import load_iris;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import classification_report;
from sklearn.metrics import mean_squared_error;  #mse
from sklearn.metrics import mean_absolute_error;  #mae
from sklearn.preprocessing import LabelEncoder;

iris=load_iris();
print(iris);
print(iris.feature_names);
print(iris.target_names);

iris_data=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\IRIS.csv');
print(iris_data);
print(iris_data.shape);
print(len(iris_data));

x_axis=iris_data[['sepal_length','sepal_width','petal_length','petal_width']];
print("The x-axis of the data set is as follows");
print(x_axis);
y_axis=iris_data['species'];
print("The y-axis of the data set is as follows");
print(y_axis);

X_train,X_test,y_train,y_test=train_test_split(x_axis,y_axis,test_size=0.33,random_state=0);
iris_model=DecisionTreeClassifier(criterion='entropy',random_state=100,max_depth=13,min_samples_leaf=5);
second_model=DecisionTreeRegressor(criterion='entropy',random_state=100,max_depth=3,min_samples_leaf=5)
x_plot=iris_data[['sepal_length','sepal_width']];
y_plot=iris_data[['petal_length','petal_width']];
#plotting the scatter plot
plt.scatter(x_plot,y_plot);
plt.hist(x_axis);
plt.show();

iris_model.fit(X_train,y_train);

#finding the score of the matrix
iris_score=iris_model.score(X_test,y_test);
print(iris_score);

lab=LabelEncoder();
iris_data['species']=lab.fit_transform(iris_data['species']);
print("The numerical value of the iris data is");
print(iris_data['species']);
y_prediction=iris_model.predict(X_test);
print(y_prediction);
cm=confusion_matrix(y_prediction,y_test);
cr=classification_report(y_prediction,y_test);
iris_score=iris_model.score(X_test,y_test);
print("The iris data set score is");print(iris_score);

sepal_length=float(input("Enter the sepal length of the flower="));
sepal_width=float(input("Enter the sepal width of the flower="));
petal_length=float(input("Enter the petal length of the flower="));
petal_width=float(input("Enter the petal width of the flower="));
print(iris_model.predict([[sepal_length,sepal_width,petal_width,petal_length]]));
print(iris_model.predict_proba([[sepal_length,sepal_width,petal_width,petal_length]]));







