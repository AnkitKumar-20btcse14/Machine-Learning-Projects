import numpy as np;
import pandas as pd;
import collections;
from collections import deque;
import matplotlib.pyplot as plt;
import seaborn as sns;
from sklearn.model_selection import train_test_split;
from sklearn.linear_model import LogisticRegression;
from sklearn.preprocessing import LabelEncoder;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import classification_report;
from sklearn.metrics import consensus_score;
from sklearn.metrics import coverage_error;
from sklearn.metrics import calinski_harabasz_score;
from sklearn.metrics import r2_score;

#wine quality prediction
wine_data=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\winequality-red.csv');
print(wine_data);
print(type(wine_data));
print(wine_data.shape);
print(len(wine_data));

#plotting the heatmap of the data
#sns.heatmap(wine_data);
#plotting the pairplot of the data
#sns.pairplot(wine_data);
#sns.histplot(wine_data);
#sns.histplot(wine_data);
#plt.show();

x_axis=wine_data[['fixed acidity','volatile acidity','citric acid','residual sugar','chlorides','free sulfur dioxide','total sulfur dioxide','density','pH','sulphates','alcohol']];
print(x_axis);
y_axis=wine_data['quality'];
print(y_axis);
print(x_axis.shape);
print(y_axis.shape);
print(len(x_axis));print(len(y_axis));

X_train,X_test,y_train,y_test=train_test_split(x_axis,y_axis,test_size=0.33,random_state=0);
wine_model=LogisticRegression();
wine_model.fit(X_train,y_train);

y_prediction=wine_model.predict(X_test);
#printing the confusion matrix
cm=confusion_matrix(y_prediction,y_test);
#printing the classification report
cr=classification_report(y_prediction,y_test);
#printing the score of the data
wine_score=wine_model.score(X_test,y_test);
print("The confusion matrix is");print(cm);
print("The classification report is");print(cr);
print("The score of the data is ");print(wine_score);

acidity=int(input("Enter the acidity amt. of the wine="));
volatile=int(input("Enter the volatile amt. of the volatile="));
citric=int(input("Enter the citirc acidity of the wine="));
residual_sugar=int(input("Enter the residual sugar amt. of the wine="));
chlorides=int(input("Enter the cholorides amt. in the wine="));
sulfur_dioxide=int(input("Enter the sulfur_dioxide rate in the wine="));
total_sulfur=int(input("Enter the sulfur dioxide rate in the wine="));
density=int(input("Enter the density of the wine="));
pH=int(input("Enter the pH of the wine="));
sulphates=int(input("Enter the sulphates amount in the wine="));
alcohol=int(input("Enter the alcohol amt. in the wine="));

print(wine_model.predict([[acidity,volatile,citric,residual_sugar,chlorides,sulfur_dioxide,total_sulfur,density,pH,sulphates,alcohol]]));


