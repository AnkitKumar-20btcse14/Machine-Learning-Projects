import numpy as np;
import pandas as pd;
import sklearn;
from sklearn.feature_extraction.text import CountVectorizer;
from sklearn.ensemble import RandomForestClassifier;
from sklearn.metrics import classification_report;
from sklearn.metrics import confusion_matrix;
from sklearn.metrics import accuracy_score;
df=pd.read_csv(r'C:\Users\hp\OneDrive\Desktop\MACHINE LEARNING RESUME PROJECTS\Stock-Sentiment-Analysis-master\Data.csv',encoding="ISO-8859-1");
print(df.head());
print(df.tail());
train=df[df['Date']<'20150101'];
test=df[df['Date']<'20141231'];
#removing the punctuations
data=train.iloc[:,2:27];
data.replace("[^a-zA-Z]"," ",regex=True,inplace=True);
#renaming the columns for ease of access
list1=[i for i in range(25)];
new_index=[str(i) for i in list1];
data.columns=new_index;
print(data.head(5));

#converting the headlines into the lowercase
for index in new_index:
    data[index]=data[index].str.lower();

print(data.head(1));

#joining
" ".join(str(x) for x in data.iloc[1,0:25]);

#joining all the data
headlines=[];
for row in range(0,len(data.index)):
    headlines.append(" ".join(str(x) for x in data.iloc[row,0:25]));

print(headlines[0]);

#implenting BAG OF WORDS
countvector=CountVectorizer(ngram_range=(2,2));
traindataset=countvector.fit_transform(headlines);

#implement Random forest classifier
randomforestclassifier=RandomForestClassifier(n_estimators=200,criterion="entropy");
randomforestclassifier.fit(traindataset,train["Label"]);

#prediction
test_transform=[];
for row in range(0,len(test.index)):
    test_transform.append(" ".join(str(x) for x in test.iloc[row,2:27]));

test_dataset=countvector.transform(test_transform);
predictions=randomforestclassifier.predict(test_dataset);

matrix=confusion_matrix(test['Label'],predictions);
print(matrix);
score=accuracy_score(test['Label'],predictions);
print(score);
report=classification_report(test['Label'],predictions);
print(report);
